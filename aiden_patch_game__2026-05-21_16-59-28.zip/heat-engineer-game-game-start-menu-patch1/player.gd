extends CharacterBody2D

const ACCELLERATION = 2100.0
const DRAG = 2100.0

@onready var hold_position = $hands
@onready var interact_ray = $grabber
@onready var anim = $player_sprite

func _physics_process(delta: float) -> void:
	var direction := Input.get_vector("left", "right", "up", "down")
	velocity = direction * Var.SPEED
	if direction != Vector2.ZERO:
		velocity = velocity.move_toward(direction * Var.SPEED, ACCELLERATION * delta)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, DRAG * delta)
	if Input.is_action_just_pressed("run"):
		if Var.SPEED == 700:
			Var.SPEED = 700 * (Var.speed_boost * Var.dash)
		else:
			Var.SPEED = Var.SPEED / Var.dash
	if Var.pause == false:
		$hands.look_at(get_global_mouse_position())
		move_and_slide()
		Var.player = self.position
	
	update_animation(direction)

func update_animation(direction: Vector2):
	if direction == Vector2.ZERO:
		anim.stop()
		return
	
	var angle = direction.angle()
	
	if angle > -0.5 and angle < 0.5:
		anim.flip_h = false
		anim.play("walk_right")
	elif angle > 2.6 or angle < -2.6:
		anim.flip_h = true
		anim.play("walk_right")
	elif angle > 0.5 and angle < 1.1:
		anim.flip_h = false
		anim.play("walk_diagonal_right")
	elif angle > 1.1 and angle < 2.0:
		anim.flip_h = false
		anim.play("walk_down")
	elif angle < -0.5 and angle > -1.1:
		anim.flip_h = false
		anim.play("walk_up_diagonal")
	elif angle < -1.1 and angle > -2.0:
		anim.flip_h = false
		anim.play("walk_up")

func _input(event):
	if event.is_action_pressed("interact"):
		if Var.held_item:
			drop()
		else:
			grab()

func grab():
	var collider = interact_ray.get_collider()
	if collider and collider.has_method("pick_up"):
		Var.held_item = Var.heater.instantiate()
		get_tree().root.add_child(Var.held_item)
		Var.held_item.pick_up(hold_position)

func drop():
	if Var.held_item:
		Var.held_item.drop(global_position, get_tree().current_scene)
		Var.held_item = null
