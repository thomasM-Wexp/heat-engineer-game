extends CanvasLayer

@onready var points_label = $Panel/PointsLabel
@onready var close_button = $Panel/CloseButton
@onready var upgrade_list = $Panel/ScrollContainer/UpgradeList

var upgrades_data = [
	["Solar Panels", "Reduce energy cost by 20%", 500, "solar_panels"],
	["Heater Efficiency", "Earn 1.5x points", 750, "heater_efficiency"],
	["Maximum Heaters", "More heater capacity", 600, "maximum_heaters"],
	["Speed Upgrade", "Move 30% faster", 400, "speed"],
	["Catnip", "Cats ignore you", 300, "catnip"],
	["Dog Toy", "Phase through dogs", 350, "dog_toy"],
	["Bird Perch", "Birds won't slow you", 250, "bird_perch"]
]

func _ready():
	hide()
	close_button.pressed.connect(_on_close_pressed)
	create_buttons()

func create_buttons():
	for child in upgrade_list.get_children():
		child.queue_free()
	
	for upgrade in upgrades_data:
		var btn = Button.new()
		btn.custom_minimum_size = Vector2(600, 60)
		
		var upgrade_id = upgrade[3]
		var cost = upgrade[2]
		var name_text = upgrade[0]
		
		if Upgrades.has_upgrade(upgrade_id):
			btn.text = name_text + " - OWNED"
			btn.disabled = true
		else:
			btn.text = name_text + " - " + str(cost) + " pts - " + upgrade[1]
			btn.pressed.connect(_on_buy.bind(upgrade_id, cost))
		
		upgrade_list.add_child(btn)

func _on_buy(upgrade_id: String, cost: int):
	if Upgrades.buy_upgrade(upgrade_id, cost):
		create_buttons()
		update_points()

func update_points():
	points_label.text = "Points: " + str(Var.points)

func open_shop():
	show()
	update_points()
	Var.pause = true

func _on_close_pressed():
	hide()
	Var.pause = false

func _process(_delta):
	if visible:
		update_points()
