extends AnimatableBody2D

func _ready() -> void:
	# Check if player has dog toy - disable collision if they do
	if Upgrades.has_upgrade("dog_toy"):
		collision_layer = 0
		collision_mask = 0

func _process(delta: float) -> void:
	pass
