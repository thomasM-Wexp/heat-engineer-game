extends Node

var owned_upgrades = {
	"solar_panels": false,
	"heater_efficiency": false,
	"maximum_heaters": false,
	"speed": false,
	"catnip": false,
	"dog_toy": false,
	"bird_perch": false
}

func buy_upgrade(upgrade_name: String, cost: int) -> bool:
	if Var.points >= cost and not owned_upgrades[upgrade_name]:
		Var.points -= cost
		owned_upgrades[upgrade_name] = true
		print(upgrade_name + " purchased!")
		return true
	return false

func has_upgrade(upgrade_name: String) -> bool:
	return owned_upgrades.get(upgrade_name, false)

func open_shop():
	get_node("/root/Shop").open_shop()
