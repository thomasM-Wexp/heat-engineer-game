extends Area2D

func _on_body_entered(_body) -> void:
	print("!!! SOMETHING ENTERED EXIT !!!")
	print("Body type: ", _body.get_class())
	print("Body name: ", _body.name)
	
	# Call leave_store for ANY body (for testing)
	var main = get_tree().get_first_node_in_group("main_scene")
	if main and main.has_method("leave_store"):
		print("CALLING LEAVE_STORE!")
		main.leave_store()
