extends Area2D

var player_nearby = false

func _ready():
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body):
	print("Something entered: ", body.name)  # ADD THIS LINE
	if body.name == "player":
		player_nearby = true
		print("Player is nearby!")  # ADD THIS LINE

func _on_body_exited(body):
	if body.name == "player":
		player_nearby = false
		

func _input(event):
	if event.is_action_pressed("interact") and player_nearby:
		print("Trying to open shop...")  # ADD THIS LINE
		Upgrades.open_shop()
