extends Node2D
signal new_level

var rooms_completed = 0
var rooms_per_floor = 2
var current_floor = 1

func _enter_tree():
	add_to_group("main_scene")
	
func _process(_delta) -> void:
	if Var.new_level == true:
		print("NEW_LEVEL TRIGGERED - LOADING NEW ROOM")
		new_room()

func new_room() -> void:
	print(">>> NEW_ROOM STARTED <<<")
	print("Rooms completed at start: ", rooms_completed)
	
	for obj in get_tree().get_nodes_in_group("room_objects"):
		obj.queue_free()
	
	print("About to call player.drop()")
	$player.drop()
	print("Player.drop() completed")
	
	Var.pause = false
	Var.new_level = false
	get_tree().call_group("rooms", "on_load")
	
	print("Rooms completed: ", rooms_completed)
	
	$player.drop()
	Var.pause = false
	Var.new_level = false
	get_tree().call_group("rooms", "on_load")
	
	print("Rooms completed: ", rooms_completed)
	
	# Check if we should go to store BEFORE loading a new room
	if rooms_completed >= rooms_per_floor:
		print("Going to store!")
		go_to_store()
		return
	
	# Load random room (exclude store)
	var room = Var.rng.randi_range(1, 5)
	print("Loading room: ", room)
	
	# Hide Store, show the selected room
	if has_node("Store"):
		$Store.visible = false
	
	var room_name = "test-room-" + str(room)
	if has_node(room_name):
		get_node(room_name).visible = true
	
	# Hide other rooms
	for i in range(1, 6):
		if i != room:
			var other_room = "test-room-" + str(i)
			if has_node(other_room):
				get_node(other_room).visible = false
	
	for i in range(len(Var.cats)):
		if room == Var.cats[i][0]:
			var instance = $cat_obstacle.duplicate()
			instance.position = Var.cats[i][1]
			instance.rotation = Var.cats[i][2]
			instance.add_to_group("room_objects")
			add_child(instance)
			instance.show()
			
	for i in range(len(Var.birds)):
		if room == Var.birds[i][0]:
			var instance = $bird_obstacle.duplicate()
			instance.position = Var.birds[i][1]
			instance.add_to_group("room_objects")
			add_child(instance)
			instance.show()
			
	for i in range(len(Var.dogs)):
		if room == Var.dogs[i][0]:
			var path = Path2D.new()
			var curve = Curve2D.new()
			for j in range(len(Var.dogs[i][1])):
				curve.add_point(Var.dogs[i][1][j])
			path.curve = curve
			add_child(path)
			var instance = $pathfinding/dog_walk.duplicate()
			instance.position = Var.dogs[i][1][0]
			path.add_to_group("room_objects")
			path.add_child(instance)
			instance.show()
			
	$player.global_position = Var.spawns[room-1]
	$player.velocity = Vector2.ZERO
	$heater.global_position = Var.base[room-1]
	print("Player position: ", $player.global_position)
	
	# Increment AFTER loading the room
	rooms_completed += 1
	
	new_level.emit()

func go_to_store():
	print("=== GO TO STORE START ===")
	
	for obj in get_tree().get_nodes_in_group("room_objects"):
		obj.queue_free()
	
	# Hide all gameplay rooms
	for i in range(1, 6):
		var room_name = "test-room-" + str(i)
		if has_node(room_name):
			get_node(room_name).visible = false
	
	# Show Store room
	if has_node("Store"):
		$Store.visible = true
	
	# Teleport player
	$player.global_position = Var.spawns[5]
	$player.velocity = Vector2.ZERO
	$heater.global_position = Var.base[5]
	
	# Force camera to follow player
	if $player.has_node("Camera2D"):
		$player/Camera2D.enabled = true
		$player/Camera2D.force_update_scroll()
	
	# CONNECT THE EXIT SIGNAL
	if $Store.has_node("exit"):
		var exit_node = $Store.get_node("exit")
		# Disconnect first if already connected to avoid duplicates
		if exit_node.body_entered.is_connected(_on_store_exit_entered):
			exit_node.body_entered.disconnect(_on_store_exit_entered)
		exit_node.body_entered.connect(_on_store_exit_entered)
		print("Store exit signal connected!")
	
	print("Player teleported to: ", $player.global_position)
	print("=== GO TO STORE END ===")
	
	new_level.emit()

# ADD THIS NEW FUNCTION AT THE BOTTOM OF main.gd:


func leave_store():
	print("=== LEAVE_STORE CALLED ===")
	rooms_completed = 0
	current_floor += 1
	Var.difficulty += 1
	Var.pause = false
	get_tree().paused = false
	print("Leaving store, resetting counter")
	
	# Call new_room directly instead of using the flag
	new_room()
	
func _on_store_exit_entered(_body):
	print("EXIT TRIGGERED!")
	leave_store()
